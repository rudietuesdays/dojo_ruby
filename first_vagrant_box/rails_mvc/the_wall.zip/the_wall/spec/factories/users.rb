FactoryGirl.define do
  factory :user do
    username "rae_rudie"
  end
end
