FactoryGirl.define do
  factory :message do
    content "This is a message"
    user
  end
end
