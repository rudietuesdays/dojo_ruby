FactoryGirl.define do
  factory :secret do
    content "My deepest darkest secret"
    user nil
  end
end
