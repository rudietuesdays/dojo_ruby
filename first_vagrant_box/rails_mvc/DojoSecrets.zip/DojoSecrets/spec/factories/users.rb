FactoryGirl.define do
  factory :user do
    name "rae gaines"
    email "rae@coder.com"
    password "password"
    password_confirmation "password"
  end
end
