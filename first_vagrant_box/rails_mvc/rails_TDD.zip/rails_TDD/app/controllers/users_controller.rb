class UsersController < ApplicationController
  def new
  end

  def create
    @user = User2.new(params.require(:user).permit(:first_name, :last_name, :email))
    if @user.save
      flash[:notice] = ["User successfully created"]
      redirect_to user_path(User2.first)
    else
      flash[:notice] = @user.errors.full_messages
      redirect_to :back
    end
  end

  def show

  end
end
