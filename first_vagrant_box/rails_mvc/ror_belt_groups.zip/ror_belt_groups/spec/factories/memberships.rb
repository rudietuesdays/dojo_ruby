FactoryGirl.define do
  factory :membership do
    user nil
    group nil
  end
end
