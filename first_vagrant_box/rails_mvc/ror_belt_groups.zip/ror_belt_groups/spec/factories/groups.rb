FactoryGirl.define do
  factory :group do
    name "MyString"
    description "MyText"
    user nil
  end
end
