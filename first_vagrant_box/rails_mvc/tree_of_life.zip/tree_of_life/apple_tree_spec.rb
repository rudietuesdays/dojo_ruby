require_relative 'apple_tree'

RSpec.describe AppleTree do
  before(:each) do
    @tree = AppleTree.new()
  end

  context 'no matter how old, the apple tree should...' do
    it 'have a getter and setter attribute of age' do
      @tree.age = 2
      expect(@tree.age).to eq(2)
    end
    it 'have only a getter attribute for height and apple count' do
      expect{@tree.height = 3}.to raise_error(NoMethodError)
      expect{@tree.apple_count = 20}.to raise_error(NoMethodError)
    end
  end

  context 'up to the age of three (3)...' do
    it 'not be able to grow apples at this age' do
      expect{@tree.year_gone_by}.to raise_error("This tree has some growing to do before it can grow apples...")
    end
  end

  context 'between the ages of three (3) and seven (7)...' do
    it 'grow apples and be able to pick them' do
      @tree.age = 3
      @tree.year_gone_by
      expect(@tree.apple_count).to eq(2)
    end
  end

  context 'above the age of seven (7)...' do
    it 'is too old to grown apples' do
      @tree.age = 7
      expect{@tree.year_gone_by}.to raise_error("This old tree won't be growing more apples.")
    end
  end
end
