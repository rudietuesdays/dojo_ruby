FactoryGirl.define do
  factory :loan do
    amount 1
    lender nil
    borrower nil
  end
end
