FactoryGirl.define do
  factory :lender do
    first_name "Jane"
    last_name "Doe"
    email "jane@coder.com"
    password "password1"
    money 1000
  end
end
