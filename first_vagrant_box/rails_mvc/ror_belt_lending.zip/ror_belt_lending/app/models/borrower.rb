class Borrower < ApplicationRecord
  has_secure_password
  has_many :loans
  has_many :money_received, through: :loans, source: :lender

  EMAIL_REGEX = /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]+)\z/i
  PASSWORD_REGEX = /(?=.*[a-zA-Z])(?=.*[0-9]).{8,}/

  attr_accessor :skip_password
  
  before_save :downcase_fields
  before_create do
    validates :password, presence: true, format: { with: PASSWORD_REGEX }, unless: :skip_password
  end

  validates :first_name, :last_name, :email, :need_title, :need_descrip, :need_amt, presence: true

  validates :email, uniqueness: { case_sensitive: false }, format: { with: EMAIL_REGEX }

  def downcase_fields
    self.email.downcase!
  end
end
