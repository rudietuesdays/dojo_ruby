class Lender < ApplicationRecord
  has_secure_password
  has_many :loans
  has_many :money_lent, through: :loans, source: :borrower

  EMAIL_REGEX = /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]+)\z/i
  PASSWORD_REGEX = /(?=.*[a-zA-Z])(?=.*[0-9]).{8,}/

  attr_accessor :skip_password

  before_save :downcase_fields
  before_create do
    validates :password, format: { with: PASSWORD_REGEX }, unless: :skip_password
  end

  validates :first_name, :last_name, :email, :money, presence: true

  validates :email, uniqueness: { case_sensitive: false }, format: { with: EMAIL_REGEX }

  def downcase_fields
    self.email.downcase!
  end

end
